from data import db_session
from data.safety import Security
sp = Security.set_password  # Функция превращения пароля в хеш
ch = Security.check_password  # Функция проверки хеша и пароля


def user_func():
    db_session.global_init("db/base.sqlite")  # Инициализация базы данных
    session = db_session.create_session()
    return session
