from flask_wtf import FlaskForm
from wtforms import PasswordField, SubmitField, TextAreaField
from wtforms.fields.html5 import EmailField, IntegerRangeField, IntegerField
from wtforms.validators import DataRequired


class Bot_form(FlaskForm):
    submit = SubmitField('Выход')
