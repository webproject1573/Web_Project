from flask_wtf import FlaskForm
from wtforms import TextAreaField


class SearchForm(FlaskForm):
    zapros = TextAreaField("Запрос")
