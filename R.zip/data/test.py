import datetime
import sqlalchemy
from sqlalchemy import orm
from werkzeug.security import generate_password_hash, check_password_hash

from .db_session import SqlAlchemyBase


def set_password(password):
    p = generate_password_hash(password)
    return p

def check_password(hash, password):
    p = check_password_hash(hash, password)
    return p
