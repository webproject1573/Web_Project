from flask import Flask, render_template, redirect, request
from data.loginform import LoginForm
from data import db_session
from data.users import User
from data.registerform import RegisterForm
from data.map_with_find_function import Map
from data.safety import Security
from data.searchform import SearchForm
from data.add_balance_form import Add_balance_form
sp = Security.set_password  # Функция превращения пароля в хеш
ch = Security.check_password  # Функция проверки хеша и пароля

copy_map = Map
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

df = 'Москва, ул. Псковская, 11'
city = df
check1 = ''
check2 = ''
hash_password = ''
email = ''
flag_for_login = ''
money = 0


@app.route('/', methods=['GET', 'POST'])
def login():
    global flag_for_login
    global money
    global hash_password
    global email
    flag_for_login = False
    form = LoginForm()
    if form.validate_on_submit():
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for em in session.query(User).filter(
                User.email == form.email.data):  # Проверка почты
            if ch(em.password, form.password.data):  # Проверка пароля
                email = em.email
                hash_password = em.password
                flag_for_login = True
                money = em.money
        if flag_for_login:
            return redirect('/bots')
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Authorization', form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User()
        user.email = form.email.data
        user.password = sp(form.password.data)
        user.submit = form.submit.data
        user.money = 0
        user.bots = ''
        user.no_money = ''
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init("db/base.sqlite")
        session = db_session.create_session()  # Инициализация базы данных
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Розбійник, вийди отсюда")

        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/map')
def the_map():
    copy_map.create(city)
    return render_template('map1.html', width=80, left=27, top=30)


@app.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        user = User()
        user.zap = form.zapros.data

    return render_template('form_for_search.html', title='выберите город', form=form)


@app.route('/bots', methods=['GET', 'POST'])
def bots():
    global flag_for_login
    global email
    global hash_password
    money = 0
    if flag_for_login:
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
            money = user.money
        if flag_for_login:
            return render_template('bots.html', title='Покупка ботов', cash=money)
    return redirect('/')


@app.route('/andrey_series', methods=['GET', 'POST'])
def andrey_series():
    global flag_for_login
    user = ''
    if flag_for_login:
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        return render_template('andrey_series.html', title='Боты для Вконтакте', cash=user.money)
    return redirect('/')


@app.route('/bory_series', methods=['GET', 'POST'])
def bory_series():
    global flag_for_login
    user = ''
    if flag_for_login:
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        return render_template('bory_series.html', title='Боты для Дискорда', cash=user.money)
    return redirect('/')


@app.route('/alice_series', methods=['GET', 'POST'])
def alice_series():
    global flag_for_login
    if flag_for_login:
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        return render_template('alice_series.html', title='Боты для Телеграмма', cash=user.money)
    return redirect('/')


@app.route('/psp_gamebot_vk', methods=['GET', 'POST'])
def psp_gamebot_vk():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email,
                                               User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '1' not in user.bots:
                if user.money >= 2500:
                    user.bots += '1'
                    user.money -= 2500
                    session.commit()
                else:
                    session.commit()
            return render_template('psp_gamebot_vk.html', cash=user.money, bots=user.bots)
        return render_template('psp_gamebot_vk.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/discord_speaker_bot', methods=['GET', 'POST'])
def discord_speaker_bot():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '2' not in user.bots:
                if user.money >= 4000:
                    user.bots += '2'
                    user.money -= 4000
                    session.commit()
                else:
                    session.commit()
            return render_template('discord_speaker_bot.html', cash=user.money, bots=user.bots)
        return render_template('discord_speaker_bot.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/discord_rolevator_bot', methods=['GET', 'POST'])
def discord_rolevator_bot():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        # Ищем пользователя в базе
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '3' not in user.bots:
                if user.money >= 1000:
                    user.bots += '3'
                    user.money -= 1000
                    session.commit()
                else:
                    session.commit()
            return render_template('discord_rolevator_bot.html', cash=user.money, bots=user.bots)
        return render_template('discord_rolevator_bot.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/parser_bot_for_telegram', methods=['GET', 'POST'])
def parser_bot_for_telegram():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        # Ищем пользователя в базе
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '4' not in user.bots:
                if user.money >= 4000:
                    user.bots += '4'
                    user.money -= 4000
                    session.commit()
                else:
                    session.commit()
            return render_template('parser_bot_for_telegram.html', cash=user.money, bots=user.bots)
        return render_template('parser_bot_for_telegram.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/bot_for_telegram_psp', methods=['GET', 'POST'])
def bot_for_telegram_psp():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '5' not in user.bots:
                if user.money >= 1000:
                    user.bots += '5'
                    user.money -= 1000
                    session.commit()
                else:
                    session.commit()
            return render_template('bot_for_telegram_psp.html', cash=user.money, bots=user.bots)
        return render_template('bot_for_telegram_psp.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/add_balance', methods=['GET', 'POST'])
def add_balance():
    global flag_for_login
    amount = ''
    check = ''
    cash_check = ''
    qq = request.args.get('qq')
    user = ''
    if flag_for_login:
        form = Add_balance_form()
        db_session.global_init("db/base.sqlite")  # Инициализация базы данных
        session = db_session.create_session()

        for user in session.query(User).filter(User.email == email,
                                               User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if form.validate_on_submit():
            if form.balance.data > 0:
                if form.balance.data < 500:
                    cash_check = 'error_small'
                else:
                    if user.money + form.balance.data > 10000:
                        cash_check = 'error'
                    else:
                        user.money += form.balance.data
                        cash_check = ''
                        check = 'ok'
                        session.commit()
            else:
                check = 'error'
        else:
            if qq == '1':  # Нажали на кнопку "пополнить на 500"
                if 500 + user.money > 10000:
                    cash_check = 'error'
                else:
                    user.money += 500
                    check = 'ok'
                    session.commit()
            if qq == '2':  # Нажали на кнопку "пополнить на 1000"
                if 1000 + user.money > 10000:
                    cash_check = 'error'
                else:
                    user.money += 1000
                    check = 'ok'
                    session.commit()
            if qq == '3':  # Нажали на кнопку "пополнить на 5000"
                if 5000 + user.money > 10000:
                    cash_check = 'error'
                else:
                    user.money += 5000
                    check = 'ok'
                    session.commit()
        return render_template('add_balance.html', cash=user.money, form=form, check=check,
                               cash_check=cash_check, amount=amount)
    return redirect('/')

@app.route('/library', methods=['GET', 'POST'])
def library():
    global flag_for_login
    user = ''
    db_session.global_init("db/base.sqlite")  # Инициализация базы данных
    session = db_session.create_session()
    for user in session.query(User).filter(User.email == email,
                                           User.password == hash_password):  # Ищем пользователя в базе

        user = user
    amount_bots = len(user.bots)
    if flag_for_login:
        return render_template('library.html', cash=user.money, bots=user.bots, amount_bots=amount_bots)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
