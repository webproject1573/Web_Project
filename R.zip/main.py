from flask import Flask, render_template, redirect, request
from data.loginform import LoginForm
from data import db_session
from data.users import User
from data.registerform import RegisterForm
# from data.jobs import Jobs
from data.map_with_find_function import Map
from data.test import set_password as sp
from data.test import check_password as ch
from data.searchform import SearchForm
from data.add_balance_form import Add_balance_form
from data.bot_form import Bot_form
import random

copy_map = Map
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

df = ('Киев', 'Звенигород', 'Денвер')
city = random.choice(df)
check1 = ''
check2 = ''
hash_password = ''
email = ''


@app.route('/', methods=['GET', 'POST'])
def login():
    global flag_for_login
    flag_for_login = False
    global money
    global hash_password
    global email
    form = LoginForm()
    if form.validate_on_submit():
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for em in session.query(User).filter(
                User.email == form.email.data):  # Проверка почты
            if ch(em.password, form.password.data):  # Проверка пароля
                email = em.email
                hash_password = em.password
                flag_for_login = True
                money = em.money
        if flag_for_login:
            return redirect('/bots')
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Authorization', form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User()
        user.email = form.email.data
        user.password = sp(form.password.data)
        user.about = form.about.data
        user.submit = form.submit.data
        user.money = 0
        user.bots = ''
        user.no_money = ''
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init("db/test.sqlite")
        session = db_session.create_session()  # Инициализация базы данных
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Розбійник, вийди отсюда")

        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/map')
def map():
    copy_map.create(city)
    return render_template('map1.html', width=80, left=27, top=30)


@app.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        user = User()
        user.zap = form.zapros.data

    return render_template('form_for_search.html', title='выберите город', form=form)


@app.route('/bots', methods=['GET', 'POST'])
def bots():
    global flag_for_login
    global email
    global hash_password
    if flag_for_login:
        money = ''
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
            money = user.money
        if flag_for_login:
            return render_template('bots.html', title='Покупка ботов', cash=money)
    return redirect('/')


@app.route('/andrey_series', methods=['GET', 'POST'])
def andrey_series():
    global flag_for_login
    if flag_for_login:
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        return render_template('andrey_series.html', title='Здесь будет боты для вк', cash=user.money)
    return redirect('/')


@app.route('/bory_series', methods=['GET', 'POST'])
def bory_series():
    global flag_for_login
    if flag_for_login:
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):
            user = user
        return render_template('bory_series.html', title='Здесь будет боты для дискорда', cash=user.money)
    return redirect('/')


@app.route('/speaker_bot', methods=['GET', 'POST'])
def speaker_bot():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email,
                                               User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '1' not in user.bots:
                if user.money > 0:
                    user.bots += '1'
                    user.money -= 500
                    session.commit()
                else:
                    user.no_money = '-'
                    session.commit()
            return render_template('speaker_bot.html', cash=user.money, bots=user.bots)
        return render_template('speaker_bot.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/real_bot', methods=['GET', 'POST'])
def real_bot():
    global flag_for_login
    if flag_for_login:
        user = ''
        qq = request.args.get('qq')
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for user in session.query(User).filter(User.email == email, User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if qq == '1':  # Нажали на кнопку "купить"
            if '2' not in user.bots:
                if user.money > 0:
                    user.bots += '2'
                    user.money -= 500
                    session.commit()
                else:
                    user.no_money = '-'
                    session.commit()
            return render_template('real_bot.html', cash=user.money, bots=user.bots)
        return render_template('real_bot.html', cash=user.money, bots=user.bots)
    return redirect('/')


@app.route('/add_balance', methods=['GET', 'POST'])
def add_balance():
    global flag_for_login
    check = ''
    cash_check = ''
    if flag_for_login:
        form = Add_balance_form()
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()

        for user in session.query(User).filter(User.email == email,
                                               User.password == hash_password):  # Ищем пользователя в базе
            user = user
        if form.validate_on_submit():
            if form.balance.data > 0:
                if user.money + form.balance.data > 5000:
                    cash_check = 'error'
                else:
                    user.money += form.balance.data
                    cash_check = ''
                    check = 'ok'
                    session.commit()
            else:
                check = 'error'

        return render_template('add_balance.html', cash=user.money, form=form, check=check, cash_check=cash_check)
    return redirect('/')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
