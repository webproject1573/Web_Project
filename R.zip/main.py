from flask import Flask, render_template, redirect
from data.loginform import LoginForm
from data import db_session
from flask_login import login_user, current_user, login_required
from data.users import User
from data.registerform import RegisterForm
from data.jobsform import JobsForm
from data.jobs import Jobs
from data.map_with_find_function import Map
from data.test import set_password as sp

copy_map = Map
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        user = session.query(User).filter(User.email == form.email.data)
        user_password = session.query(User).filter(User.password == sp(form.password.data))
        if user and user_password:
            # login_user(user, remember=form.remember_me.data)
            return redirect('/search')
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Authorization', form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User()
        user.email = form.email.data
        user.password = form.password.data
        user.password = user.set_password(user.password)
        user.about = form.about.data
        user.submit = form.submit.data

        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init("db/test.sqlite")
        session = db_session.create_session()  # Инициализация базы данных
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")

        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/map')
def map():
    copy_map.create()
    return render_template('map1.html', width=80, left=27, top=30)


@app.route('/search')
def search():
    return render_template('search.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
