from flask import Flask, render_template, redirect
from data.loginform import LoginForm
from data import db_session
from data.users import User
from data.registerform import RegisterForm
# from data.jobs import Jobs
from data.map_with_find_function import Map
from data.test import set_password as sp
from data.test import check_password as ch
from data.searchform import SearchForm
import random


copy_map = Map
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

df = ('Киев', 'Звенигород', 'Денвер')
city = random.choice(df)
flag_for_login = False
money = 0


@app.route('/', methods=['GET', 'POST'])
def login():
    global flag_for_login
    global money
    form = LoginForm()
    if form.validate_on_submit():
        db_session.global_init("db/test.sqlite")  # Инициализация базы данных
        session = db_session.create_session()
        for em in session.query(User).filter(
                User.email == form.email.data):  # Проверка почты
            if ch(em.password, form.password.data):  # Проверка пароля
                flag_for_login = True
                money = em.money
        if flag_for_login:
            return redirect('/bots')
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Authorization', form=form)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User()
        user.email = form.email.data
        user.password = sp(form.password.data)
        user.about = form.about.data
        user.submit = form.submit.data
        user.money = 1500
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init("db/test.sqlite")
        session = db_session.create_session()  # Инициализация базы данных
        print(User.email)
        if session.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Розбійник, вийди от сюда")

        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/map')
def map():
    copy_map.create(city)
    return render_template('map1.html', width=80, left=27, top=30)


@app.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm()
    if form.validate_on_submit():
        user = User()
        user.zap = form.zapros.data

    return render_template('form_for_search.html', title='выберите город', form=form)

@app.route('/bots', methods=['GET', 'POST'])
def bots():
    global flag_for_login
    if flag_for_login:
        # flag_for_login = False
        user = User()
        user.money = 1500
        return render_template('bots.html', title='Покупка ботов', cash=user.money)

@app.route('/bot1', methods=['GET', 'POST'])
def bot1():
    global money
    return render_template('bot1.html', title='Здесь будет 1 бот', cash=money)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
