import discord
from discord.ext import commands

client_ = commands.Bot(command_prefix='.')
TOKEN = 'XXXXXXXXXXXXXXXXXXXXXXXXXX'

@client_.command(pass_context=True)
async def clear(ctx, amount=100):
    await ctx.channel.purge(limit=amount)

client_.run(TOKEN)