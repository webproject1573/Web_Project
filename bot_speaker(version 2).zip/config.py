TOKEN = 'XXXXXXXXXXXXXXXXXXXXX' 
# указываем ТОКЕН для точто чтобы подключится к серверу

usual_role = 'XXXXXXXXXXXX'
# ID обычной роли 