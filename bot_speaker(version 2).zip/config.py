TOKEN = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
# указываем ТОКЕН для точто чтобы подключится к серверу

usual_role = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXx'
# ID обычной роли 