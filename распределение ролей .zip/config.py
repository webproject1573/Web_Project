TOKEN = "NzA1MzE3ODkxNTc4Mzk2NzMz.XrVU-A.KZQLsEJRAp078HGVvrIIl3FLYZo"
# bot token

POST_ID = 705128184533876767 
# post id to read reactions from

# roles list according to emotes
ROLES = {
    "🎮": 705121160723038278,
    # gamer role
    "🎧": 705121168461660220,
    # it
    "🎓": 705121496451776640,
    # scienctist user
}

# exclude this roles from counting
EXCROLES = ()

MAX_ROLES_PER_USER = 2
# max amount of roles a user can have